<html>
	<head></head>
	<body>
		<?php 
		$h=$_GET['hob'];
		$e=$_GET['edu'];
		print "<h2>Your Account has been successfully created........</h2>";
		print "<h6>Hobbies:$h<br>
		Education:$e</h6>";
		?>		
		</body>
</html>