<html>
	<head></head>
	<body>
		<?php 
		$nam=$_GET['myname'];
		print "<h2>Hello $nam.......!</h2>";
		print "<h4>Please fillout the following form to create your profile.</h4>";
		?>		
		<form method="get" action="third.php">
		Hobbies:<input type="text" name="hob"><br>
		Education:<input type="text" name="edu"><br>
			<input type="submit" value="submit">
		</form>
	</body>
</html>